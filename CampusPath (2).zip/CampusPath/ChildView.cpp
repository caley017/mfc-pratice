﻿
// ChildView.cpp : implementation of the CChildView class
//

#include "pch.h"
#include "framework.h"
#include "CampusPath.h"

#include "ChildView.h"
#include "resource.h"   // IDB_MAP

#include <queue>
#include <cmath>
#include <functional>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CChildView::CChildView()
{
    m_firstCtrlIndex = -1;
    m_firstAltIndex = -1;
    m_bgLoaded = false;
    m_hasShortestPath = false;
    m_lastDistance = 0.0;
}

CChildView::~CChildView()
{
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
    ON_WM_PAINT()
    ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
    if (!CWnd::PreCreateWindow(cs))
        return FALSE;

    cs.dwExStyle |= WS_EX_CLIENTEDGE;
    cs.style &= ~WS_BORDER;
    cs.lpszClass = AfxRegisterWndClass(
        CS_HREDRAW | CS_VREDRAW,
        ::LoadCursor(nullptr, IDC_ARROW),
        reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1),
        nullptr);

    return TRUE;
}

// 배경 비트맵 로딩 --------------------------------------

void CChildView::LoadBackgroundBitmap()
{
    if (m_bgLoaded)
        return;

    m_bgLoaded = true;

    if (!m_bgBitmap.LoadBitmap(IDB_MAP))
    {
        AfxMessageBox(L"IDB_MAP 비트맵을 불러오지 못했습니다.\n"
            L"리소스 뷰에서 Bitmap → IDB_MAP 이 있는지 확인하세요.");
    }
}

// 그리기 ------------------------------------------------

void CChildView::OnPaint()
{
    CPaintDC dc(this);

    // 1) 배경 지도
    LoadBackgroundBitmap();

    if (m_bgBitmap.GetSafeHandle() != NULL)
    {
        CDC memDC;
        memDC.CreateCompatibleDC(&dc);
        CBitmap* pOldBmp = memDC.SelectObject(&m_bgBitmap);

        BITMAP bm;
        m_bgBitmap.GetBitmap(&bm);

        dc.BitBlt(0, 0, bm.bmWidth, bm.bmHeight,
            &memDC, 0, 0, SRCCOPY);

        memDC.SelectObject(pOldBmp);
    }
    else
    {
        CRect rc;
        GetClientRect(&rc);
        dc.FillSolidRect(rc, RGB(255, 255, 255));
    }

    // 2) 간선(경로) 그리기
    CPen bluePen(PS_SOLID, 2, RGB(0, 0, 255));   // 기본 파란 경로
    CPen redPen(PS_SOLID, 3, RGB(255, 0, 0));    // 최단 경로

    CPen* pOldPen = dc.SelectObject(&bluePen);

    size_t i;

    // 모든 파란 경로
    for (i = 0; i < m_edges.size(); ++i)
    {
        const EDGE& e = m_edges[i];
        const NODE& n1 = m_nodes[e.from];
        const NODE& n2 = m_nodes[e.to];

        dc.MoveTo(n1.pos);
        dc.LineTo(n2.pos);
    }

    // 최단 경로만 빨간색으로 덮어 그리기
    dc.SelectObject(&redPen);
    for (i = 0; i < m_edges.size(); ++i)
    {
        const EDGE& e = m_edges[i];
        if (!e.onShortestPath) continue;

        const NODE& n1 = m_nodes[e.from];
        const NODE& n2 = m_nodes[e.to];

        dc.MoveTo(n1.pos);
        dc.LineTo(n2.pos);
    }

    dc.SelectObject(pOldPen);

    // 3) 각 간선의 거리 텍스트 (선 중간에)
    int oldBkMode = dc.SetBkMode(TRANSPARENT);
    COLORREF oldColor = dc.SetTextColor(RGB(0, 0, 0));

    for (i = 0; i < m_edges.size(); ++i)
    {
        const EDGE& e = m_edges[i];
        const NODE& n1 = m_nodes[e.from];
        const NODE& n2 = m_nodes[e.to];

        int midX = (n1.pos.x + n2.pos.x) / 2;
        int midY = (n1.pos.y + n2.pos.y) / 2;

        CString txt;
        txt.Format(L"%.0f", e.weight); // 픽셀 거리

        dc.TextOutW(midX + 3, midY + 3, txt);
    }

    // 4) 노드(점) 그리기
    const int r = 5;
    CBrush blueBrush(RGB(0, 0, 255));
    CBrush redBrush(RGB(255, 0, 0));
    CPen nullPen(PS_NULL, 0, RGB(0, 0, 0));

    CPen* pOldPen2 = dc.SelectObject(&nullPen);
    CBrush* pOldBrush = dc.SelectObject(&blueBrush);

    for (i = 0; i < m_nodes.size(); ++i)
    {
        const NODE& n = m_nodes[i];

        if (n.isRed)
            dc.SelectObject(&redBrush);
        else
            dc.SelectObject(&blueBrush);

        dc.Ellipse(n.pos.x - r, n.pos.y - r,
            n.pos.x + r, n.pos.y + r);
    }

    dc.SelectObject(pOldBrush);
    dc.SelectObject(pOldPen2);

    // 5) 최단 거리 텍스트 (화면 왼쪽 위)
    if (m_hasShortestPath)
    {
        CString txt;
        txt.Format(L"최단 거리: %.0f (픽셀)", m_lastDistance);

        dc.SetTextColor(RGB(255, 0, 0));
        dc.TextOutW(10, 10, txt);
    }

    dc.SetTextColor(oldColor);
    dc.SetBkMode(oldBkMode);
}

// 노드 히트 테스트 --------------------------------------

int CChildView::HitTestNode(CPoint pt) const
{
    const int hitRadius = 8;
    const int hit2 = hitRadius * hitRadius;

    for (size_t i = 0; i < m_nodes.size(); ++i)
    {
        int dx = pt.x - m_nodes[i].pos.x;
        int dy = pt.y - m_nodes[i].pos.y;
        if (dx * dx + dy * dy <= hit2)
            return (int)i;
    }
    return -1;
}

// 간선 추가 ---------------------------------------------

void CChildView::AddEdge(int a, int b)
{
    if (a == b) return;

    // 이미 존재하는 간선이면 패스
    size_t i;
    for (i = 0; i < m_edges.size(); ++i)
    {
        EDGE& e = m_edges[i];
        if ((e.from == a && e.to == b) ||
            (e.from == b && e.to == a))
            return;
    }

    EDGE e;
    e.from = a;
    e.to = b;

    CPoint p1 = m_nodes[a].pos;
    CPoint p2 = m_nodes[b].pos;
    double dx = (double)(p1.x - p2.x);
    double dy = (double)(p1.y - p2.y);
    e.weight = std::sqrt(dx * dx + dy * dy); // 픽셀 거리
    e.onShortestPath = false;

    m_edges.push_back(e);
}

// 다익스트라 최단 경로 ----------------------------------

void CChildView::ComputeShortestPath(int start, int end)
{
    int n = (int)m_nodes.size();
    if (start < 0 || start >= n || end < 0 || end >= n)
        return;
    if (m_edges.empty())
        return;

    std::vector< std::vector< std::pair<int, double> > > adj;
    adj.resize(n);

    size_t i;
    for (i = 0; i < m_edges.size(); ++i)
    {
        const EDGE& e = m_edges[i];
        adj[e.from].push_back(std::make_pair(e.to, e.weight));
        adj[e.to].push_back(std::make_pair(e.from, e.weight)); // 양방향
    }

    const double INF = 1e18;
    std::vector<double> dist(n, INF);
    std::vector<int>    prev(n, -1);

    typedef std::pair<double, int> NodePair; // (거리, 노드)
    std::priority_queue<NodePair,
        std::vector<NodePair>,
        std::greater<NodePair> > pq;

    dist[start] = 0.0;
    pq.push(NodePair(0.0, start));

    while (!pq.empty())
    {
        NodePair top = pq.top();
        pq.pop();

        double d = top.first;
        int u = top.second;

        if (d > dist[u]) continue;
        if (u == end) break;

        size_t k;
        for (k = 0; k < adj[u].size(); ++k)
        {
            int v = adj[u][k].first;
            double w = adj[u][k].second;

            if (dist[v] > dist[u] + w)
            {
                dist[v] = dist[u] + w;
                prev[v] = u;
                pq.push(NodePair(dist[v], v));
            }
        }
    }

    if (dist[end] == INF)
    {
        AfxMessageBox(L"두 노드를 잇는 경로가 없습니다.");
        m_hasShortestPath = false;
        return;
    }

    // 이전 최단 경로 표시 초기화
    size_t i2;
    for (i2 = 0; i2 < m_edges.size(); ++i2)
        m_edges[i2].onShortestPath = false;

    // prev 배열로 경로 복원
    double total = 0.0;
    int v = end;
    while (prev[v] != -1)
    {
        int u = prev[v];

        for (i2 = 0; i2 < m_edges.size(); ++i2)
        {
            EDGE& e = m_edges[i2];
            if ((e.from == u && e.to == v) ||
                (e.from == v && e.to == u))
            {
                e.onShortestPath = true;
                total += e.weight;
                break;
            }
        }
        v = u;
    }

    // 노드 색 초기화 → 시작/끝만 빨간색
    for (i2 = 0; i2 < m_nodes.size(); ++i2)
        m_nodes[i2].isRed = false;

    m_nodes[start].isRed = true;
    m_nodes[end].isRed = true;

    m_hasShortestPath = true;
    m_lastDistance = total;
}

// 마우스 왼쪽 버튼 --------------------------------------

void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
    BOOL ctrlDown = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    BOOL altDown = (GetKeyState(VK_MENU) & 0x8000) != 0;

    int idx = HitTestNode(point);

    // 1) 그냥 클릭 → 새 파란 노드
    if (!ctrlDown && !altDown)
    {
        if (idx == -1)
        {
            NODE node;
            node.pos = point;
            node.isRed = false;
            m_nodes.push_back(node);

            Invalidate(FALSE);
        }
    }
    // 2) Ctrl + 클릭 → 두 노드 파란 선으로 연결
    else if (ctrlDown)
    {
        if (idx == -1)
            return;

        if (m_firstCtrlIndex == -1)
        {
            m_firstCtrlIndex = idx;
        }
        else
        {
            if (m_firstCtrlIndex != idx)
            {
                AddEdge(m_firstCtrlIndex, idx);
            }
            m_firstCtrlIndex = -1;
        }
        Invalidate(FALSE);
    }
    // 3) Alt + 클릭 → 두 노드 사이 최단 경로
    else if (altDown)
    {
        if (idx == -1)
            return;

        if (m_firstAltIndex == -1)
        {
            m_firstAltIndex = idx;
        }
        else
        {
            if (m_firstAltIndex != idx)
            {
                int start = m_firstAltIndex;
                int end = idx;
                m_firstAltIndex = -1;

                ComputeShortestPath(start, end);
                Invalidate(FALSE);
            }
        }
    }

    CWnd::OnLButtonDown(nFlags, point);
}
